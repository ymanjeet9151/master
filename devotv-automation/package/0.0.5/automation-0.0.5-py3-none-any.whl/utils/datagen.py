from faker import Faker
import random
import string
import time

fake = Faker('en_US')


def generate_email():
    """
    Generate fake Email using Faker Lib
    :return: snehil.mishra@impressico.com
    """
    return time.strftime('%m%d%y%H%M%S', time.localtime()) + fake.email()


def generate_first_name():
    """
    Generate fake First Name using Faker Lib
    :return: Automation
    """
    return fake.first_name()


def generate_middle_name():
    """
    Generate random Middle Name
    :return: P
    """
    return random.choice(string.ascii_uppercase)


def generate_last_name():
    """
    Generate fake Last Name using Faker Lib
    :return: QA
    """
    return fake.last_name()


def generate_state():
    """
    Select State using Random Lib
    :return: NY
    """
    state = ['NY', 'FL', 'MA', 'AZ', 'NJ', 'CA', 'LA', 'OH', 'WI', 'IL', 'AR', 'TX']
    return random.choice(state)


def generate_zip_code():
    """
    Generate fake Zip Code using Random Lib
    :return: 10001
    """
    return random.randrange(10000, 99999)


def generate_phone():
    """
    Generate Phone using Random Lib
    :return: 9876543210
    """
    return random.randrange(1000000000, 9999999999)


def generate_ssn():
    """
    Generate fake SSN using Faker Lib
    :return: 908-89-1234
    """
    return fake.ssn()


def generate_address():
    """
    Generate Street Address line 1 using Faker Lib
    :return: 831 Allen Rd.
    """
    return fake.street_address()


def generate_city():
    """Generate City  using Faker Lib
    :return: Dayton
    """
    return fake.city()


def generate_secondary_address():
    """
    Generate street address line 2 using Faker Lib
    :return: fort
    """
    return fake.city_suffix()


def generate_date_of_birth():
    """
    Generate Date of Birth in mmddyy using Faker Lib
    :return: 09/12/1987
    """
    return fake.date_of_birth(minimum_age=21, maximum_age=80).strftime('%m/%d/%Y')


def generate_routing_number():
    """
    Generate Bank Routing Number using Faker Lib
    :return: 082333643
    """
    return fake.aba()


def generate_bank_account_number():
    """
    Generate Basic Bank Account Number using Faker Lib
    :return: WRRB23520835508179
    """
    return fake.bban()


def generate_financial_institution_name():
    """
    Generate Financial Institution Name using Faker Lib
    :return: monetize compelling systems bank
    """
    return fake.bs() + " bank"
